<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 */

get_header(); ?>

	//No page found message here

<?php get_footer(); ?>