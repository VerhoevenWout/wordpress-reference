<?php
/**
 * The template for displaying the footer
 *
 */
?>

<footer>
	<p class="volta"><a class="volta" alt="Webdesign Antwerpen Volta" title="Webdesign Antwerpen Volta" href="http://www.volta.be" target="_blank">Webdesign&nbsp;Antwerpen&nbsp;Volta</a></p>
</footer>

<!-- build:js dist/js/vendor.js -->
<!-- bower:js -->
<!-- endbower -->
<!-- endbuild -->

<script src="<?php bloginfo('template_url'); ?>/dist/js/main.js" type="text/javascript"></script>

</body>
</html>